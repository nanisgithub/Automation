{% test client_specific_checks(model) %}
    {% set healthplan = var('healthplan') %}
    {% set config_data = fromyaml(load_file('models/validations/Client_Specific_Rules.yml')) %}
    {% set client_rules = config_data['client_specific_rules'] | selectattr('HealthPlan', 'equalto', healthplan) | list %}

    {% if client_rules | length == 0 %}
        {{ exceptions.raise_compiler_error("No rules configured for HealthPlan: " ~ healthplan) }}
    {% endif %}

    {% set rule_set = client_rules[0]['Tests'] %}
    {% set result_queries = [] %}

    {% for rule in rule_set %}
        {% if rule['type'] == 'duplicate_check' %}
            {% set cols = rule['columns'] %}
            {% set query %}
                select '{{ rule.get('test_name', 'DuplicateCheck') }}' as test_name,
                       {{ cols | join(', ') }},
                       count(*) as duplicate_count
                from {{ model }}
                where HealthPlan = '{{ healthplan }}'
                group by {{ cols | join(', ') }}
                having count(*) > 1
            {% endset %}
            {% do result_queries.append(query) %}

        {% elif rule['type'] == 'null_check' %}
            {% for col in rule['columns'] %}
                {% set query %}
                    select '{{ rule.get('test_name', col ~ '_NullCheck') }}' as test_name,
                           count(*) as null_count
                    from {{ model }}
                    where HealthPlan = '{{ healthplan }}'
                      and ({{ col }} is null or {{ col }} = '')
                {% endset %}
                {% do result_queries.append(query) %}
            {% endfor %}
        {% endif %}
    {% endfor %}

    {% set final_query = result_queries | join(' union all ') %}
    {{ return(final_query) }}
{% endtest %}
