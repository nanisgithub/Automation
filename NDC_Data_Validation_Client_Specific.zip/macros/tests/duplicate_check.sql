{% test duplicate_check(model) %}

    {% set healthplan = var('healthplan') %}
    {% set config_path = 'models/validations/DuplicateCheck_ByClient.yml' %}
    {% set config_data = fromyaml(load_file(config_path)) %}
    {% set match = config_data['duplicate_checks'] | selectattr('HealthPlan', 'equalto', healthplan) | list %}

    {% if match | length == 0 %}
        {{ exceptions.raise_compiler_error("No duplicate rule configured for HealthPlan: " ~ healthplan) }}
    {% endif %}

    {% set check = match[0] %}
    {% set cols = check['Columns'] %}

    select
        {{ cols | join(', ') }},
        count(*) as duplicate_count
    from {{ model }}
    where HealthPlan = '{{ healthplan }}'
    group by {{ cols | join(', ') }}
    having count(*) > 1

{% endtest %}
