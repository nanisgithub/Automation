# NDC Data Validation & Profiling Project

This DBT project validates and profiles the `NDC_FileValidation_SourceData` materialized view. It supports two main processes:
1. **Rule-Based Data Validation**
2. **Column-Level Data Profiling**

---

## ✅ Core Features

### 1. Rule-Based Data Validation
- Centralized YAML definitions for rules (`NDC_RuleCheck.yml`)
- Custom test macros:
  - `column_null_check`
  - `conditional_value_check`
  - `cross_reference_check`
- Test results logged to: `DBT_ndc_validation_summary_log`
- Full `dbt test` support with dynamic parameters (healthplan, process ID)

### 2. Column-Level Data Profiling
- Profiles selected columns using `vars:` in `NDC_ProfilingCheck.yml`
- Logs null %, min/max, distinct count to summary table
- No profiling table is created — macro handles logging directly
- Profiling triggered via ephemeral model `ndc_profile_summary_log.sql`


---

## 📂 Folder Structure Overview


NDC_Data_Validation/
├── dbt_project.yml
├── README.md
├── macros/
│   ├── column_null_check.sql
│   ├── conditional_value_check.sql
│   ├── reference_table_check.sql
│   └── log_profile_to_summary.sql
├── models/
│   ├── staging/
│   │   └── NDC_FileValidation_SourceData.sql
│   ├── validations/
│   │   └── NDC_RuleCheck.yml
│   └── profiling/
│       └── ndc_profile_summary_log.sql
├── tests/
├── logs/
└── target/


---

## How It Works

### Validation
- Rules are defined in `NDC_RuleCheck.yml` under `tests:`.
- Includes null checks, conditional checks, and reference lookups.

### Profiling
- Columns to profile are defined under `vars:` in the same YAML.
- Metrics include: null %, min, max, distinct count.
- Results go to `DBT_NDC_Validation_SummaryLog` in SQL Server.

---


## Run Commands

**Run Validations Only:**
```bash
dbt test --select tag:validation --vars '{"healthplan": "MolinaOH", "processid": "PRC10939013707"}'
```

**Run Profiling Only:**
```bash
dbt run --select tag:profiling --vars '{"healthplan": "MolinaOH", "processid": "PRC10939013707"}'
```

**Combined Run Using Batch Script:**
```bash
.\run_dbt_with_inputs.bat
```

---

## Tips
- Keep `profiling_columns` at the `vars:` root of `dbt_project.yml`.
- Tag your profiling model with `tags: ['profiling']`.
---

## Future Enhancements

- Data Integrity Checks
- Error Logging the process
- Alerts for Process Errors
- Dashboard integration (Power BI / Looker)
- Production versioning for deployment

---

**Built with**: dbt, Jinja2, SQL Server  
**Maintainer**: Srikanth Reddy